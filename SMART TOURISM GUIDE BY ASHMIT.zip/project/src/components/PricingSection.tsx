import React from 'react';
import { Check } from 'lucide-react';

const PRICING_PLANS = [
  {
    name: 'Basic',
    price: '₹799',
    features: ['Access to basic city guides', '24/7 customer support', 'Mobile app access'],
    recommended: false
  },
  {
    name: 'Premium',
    price: '₹1,499',
    features: ['All basic features', 'Personalized recommendations', 'Offline maps', 'Priority support'],
    recommended: true
  },
  {
    name: 'Pro',
    price: '₹2,499',
    features: ['All premium features', 'Private guide booking', 'Custom itineraries', 'Group discounts'],
    recommended: false
  }
];

export function PricingSection() {
  return (
    <section className="py-16 bg-gray-50" id="pricing">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Choose Your Travel Plan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PRICING_PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`bg-white rounded-xl shadow-lg p-8 ${
                plan.recommended ? 'ring-2 ring-blue-500 transform scale-105' : ''
              }`}
            >
              {plan.recommended && (
                <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium mb-4 inline-block">
                  Recommended
                </span>
              )}
              <h3 className="text-2xl font-bold mb-4">{plan.name}</h3>
              <p className="text-4xl font-bold mb-6">{plan.price}<span className="text-gray-500 text-base">/month</span></p>
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <button className={`w-full py-2 rounded-lg font-medium ${
                plan.recommended
                  ? 'bg-blue-500 text-white hover:bg-blue-600'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}>
                Get Started
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}