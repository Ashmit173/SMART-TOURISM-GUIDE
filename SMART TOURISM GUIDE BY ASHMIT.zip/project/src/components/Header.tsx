import React from 'react';
import { Map, Navigation, Search } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Map className="h-8 w-8" />
            <h1 className="text-2xl font-bold">Smart Tourism Guide</h1>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#spots" className="flex items-center space-x-1 hover:text-blue-200 transition">
              <Navigation className="h-4 w-4" />
              <span>Tourist Spots</span>
            </a>
            <a href="#recommendations" className="hover:text-blue-200 transition">Recommendations</a>
            <a href="#services" className="hover:text-blue-200 transition">Services</a>
          </nav>
        </div>
      </div>
    </header>
  );
}