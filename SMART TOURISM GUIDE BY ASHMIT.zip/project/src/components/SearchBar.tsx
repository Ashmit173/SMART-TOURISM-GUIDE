import React from 'react';
import { Search, MapPin } from 'lucide-react';

export function SearchBar() {
  return (
    <div className="relative max-w-2xl mx-auto">
      <div className="flex items-center bg-white rounded-lg shadow-md">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search for tourist spots..."
              className="w-full pl-10 pr-4 py-3 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <div className="px-4 border-l border-gray-200">
          <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-600">
            <MapPin className="h-5 w-5" />
            <span>Near Me</span>
          </button>
        </div>
      </div>
    </div>
  );
}