import React from 'react';
import { Timer, Users, Percent } from 'lucide-react';

export function DiscountSection() {
  return (
    <section className="py-16 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Special Offers</h2>
          <p className="text-xl text-blue-100">Don't miss out on these amazing deals!</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
            <Timer className="h-12 w-12 mb-4 text-blue-200" />
            <h3 className="text-xl font-bold mb-2">Early Bird Discount</h3>
            <p className="text-blue-100 mb-4">Book 30 days in advance and get 20% off on any package</p>
            <span className="text-2xl font-bold text-yellow-300">Save 20%</span>
          </div>
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
            <Users className="h-12 w-12 mb-4 text-blue-200" />
            <h3 className="text-xl font-bold mb-2">Group Packages</h3>
            <p className="text-blue-100 mb-4">Special rates for groups of 5 or more people</p>
            <span className="text-2xl font-bold text-yellow-300">Save 25%</span>
          </div>
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
            <Percent className="h-12 w-12 mb-4 text-blue-200" />
            <h3 className="text-xl font-bold mb-2">Season Pass</h3>
            <p className="text-blue-100 mb-4">Unlimited access to premium features for 3 months</p>
            <span className="text-2xl font-bold text-yellow-300">Save 30%</span>
          </div>
        </div>
      </div>
    </section>
  );
}