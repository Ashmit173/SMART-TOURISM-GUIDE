import React from 'react';
import { Clock, MapPin, Star, Tag } from 'lucide-react';
import { TouristSpot } from '../types/spot';

interface SpotCardProps {
  spot: TouristSpot;
}

export function SpotCard({ spot }: SpotCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-[1.02]">
      <div className="relative h-48">
        <img 
          src={spot.image} 
          alt={spot.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
          <span className="flex items-center text-sm font-medium text-gray-800">
            <Tag className="h-3 w-3 mr-1" />
            {spot.category}
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-xl font-semibold mb-2">{spot.title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-2">{spot.description}</p>
        
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 text-yellow-400" />
            <span className="font-medium">{spot.rating}</span>
          </div>
          <div className="flex items-center space-x-1">
            <MapPin className="h-4 w-4" />
            <span>{spot.distance}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="h-4 w-4" />
            <span>{spot.openHours}</span>
          </div>
        </div>
      </div>
    </div>
  );
}