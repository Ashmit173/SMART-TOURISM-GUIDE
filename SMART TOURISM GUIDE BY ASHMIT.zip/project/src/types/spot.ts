export interface TouristSpot {
  id: string;
  title: string;
  image: string;
  description: string;
  rating: number;
  distance: string;
  openHours: string;
  category: string;
}