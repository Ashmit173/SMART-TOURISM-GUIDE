import { TouristSpot } from '../types/spot';

export const TOURIST_SPOTS: TouristSpot[] = [
  {
    id: 'taj-mahal',
    title: "Taj Mahal",
    image: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1600&q=80",
    description: "One of the world's most iconic monuments, this ivory-white marble mausoleum is a testament to eternal love. Experience the breathtaking architecture and beautiful gardens.",
    rating: 4.9,
    distance: "2.5 km",
    openHours: "6AM-7PM",
    category: "Heritage"
  },
  {
    id: 'rose-garden',
    title: "Rose Garden Chandigarh",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMzsnuvzt_HVjaP06wAuCALkdEwECn7VPs9w&s",
    description: "Asia's largest rose garden, featuring over 1,600 species of roses spread across 40 acres. Perfect for nature lovers and photography enthusiasts.",
    rating: 4.6,
    distance: "3.1 km",
    openHours: "9AM-6PM",
    category: "Nature"
  },
  {
    id: 'kangra-museum',
    title: "Kangra Royal Museum",
    image: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0c/3a/72/60/photo7jpg.jpg?w=1200&h=-1&s=1",
    description: "Discover the rich heritage of the Katoch clan in this royal museum. Features ancient artifacts, royal memorabilia, and traditional Kangra art collections.",
    rating: 4.7,
    distance: "1.8 km",
    openHours: "10AM-5PM",
    category: "Culture"
  }
];