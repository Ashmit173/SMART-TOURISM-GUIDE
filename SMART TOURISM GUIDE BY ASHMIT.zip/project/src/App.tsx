import React from 'react';
import { Header } from './components/Header';
import { SearchBar } from './components/SearchBar';
import { RecommendationSection } from './components/RecommendationSection';
import { PricingSection } from './components/PricingSection';
import { DiscountSection } from './components/DiscountSection';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 py-20">
        <div className="container mx-auto px-4 text-center text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Discover Amazing Places
          </h1>
          <p className="text-xl mb-8 text-blue-100">
            Find the best tourist spots and get personalized recommendations
          </p>
          <SearchBar />
        </div>
      </section>

      {/* Main Content */}
      <main>
        <RecommendationSection />
        
        {/* Services Section */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-8">Travel Services</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-6 rounded-lg bg-gray-50">
                <h3 className="text-xl font-semibold mb-4">Easy Navigation</h3>
                <p className="text-gray-600">Find your way around with intuitive maps and directions</p>
              </div>
              <div className="p-6 rounded-lg bg-gray-50">
                <h3 className="text-xl font-semibold mb-4">Real-Time Updates</h3>
                <p className="text-gray-600">Get instant updates about nearby attractions and events</p>
              </div>
              <div className="p-6 rounded-lg bg-gray-50">
                <h3 className="text-xl font-semibold mb-4">Personal Guide</h3>
                <p className="text-gray-600">Customized recommendations based on your preferences</p>
              </div>
            </div>
          </div>
        </section>

        <PricingSection />
        <DiscountSection />
      </main>

      <Footer />
    </div>
  );
}

export default App;